﻿using System;

namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk
{
    public class Line
    {
        public Line()
        {
            _k = 1;
            _b = 0;
        }
        public Line(double b)
        {
            _k = 1;
            _b = b;
        }
        public Line(double k, double b)
        {
            _k = k;
            _b = b;
        }
        public Line(double x1, double y1, double x2, double y2)
        {
            _k = (y2 - y1) / (x2 - x1);
            _b = y1 - _k * x1;
        }
        public Line(Point p1, Point p2)
        {
            _k = (p2.Y - p1.Y) / (p2.X - p1.X);
            _b = p1.Y - _k * p1.X;
        }

        private double _k; // угол наклона
        private double _b; // свободный член

        public bool IsYMore(double x, double y)
        {
            if (y > _k * x + _b)
                return true;
            else
                return false;
        }
        public bool IsYMore(Point point)
        {
            if (point.Y > _k * point.X + _b)
                return true;
            else
                return false;
        }
    }
}
