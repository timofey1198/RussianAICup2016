using Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk.Model;
using System;

namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk
{
    public sealed class MyStrategy : IStrategy
    {
        public static double needAngle;
        public static double Pi = Math.PI;
        public static bool stop;
        public static Random rnd = new Random();
        public static Line l1 = new Line(250);
        public static Line l2 = new Line(1200, 4000, 3600, 800);
        public static Line l3 = new Line(0, 2800, 3200, 400);
        public static bool bonus = false;

        public void Move(Wizard self, World world, Game game, Move move)
        {
            int bonusTime = (int)(self.GetDistanceTo(2800, 2800) / 4.5);
            Point safePlace = SafePlace(self, world);
            needAngle = world.TickIndex > 200 ? self.GetAngleTo(world.Width, 0) : self.GetAngleTo(world.Width, world.Width);
            move.Speed = world.TickIndex < 100 ? 0 : 4;
            move.Action = ActionType.MagicMissile;
            Attack(self, move, world);
            
            if ((bonus || world.TickIndex % 2500 > 2500 - bonusTime) && !l1.IsYMore(self.X, self.Y))
            {
                bonus = true;
                needAngle = self.GetAngleTo(2800, 2800);
                if (self.GetDistanceTo(2800, 2800) < self.Radius)
                    bonus = false;
            }
            if (!stop)
                move.Turn = FreeAngle(self, world, needAngle);
            if (self.Life < 0.55 * self.MaxLife)
            {
                if (self.GetDistanceTo(Find.NearestEnemyUnit(self, world)) < 400)
                {
                    move.Speed = -1;
                    move.Turn = FreeAngle(self, world, self.GetAngleTo(safePlace.X, safePlace.Y)) + Pi / 2;
                }
            }
            if (self.Life < 0.45 * self.MaxLife)
            {
                if (self.GetDistanceTo(Find.NearestEnemyUnit(self, world)) < 500)
                {
                    move.Speed = -1.7;
                    move.Turn = FreeAngle(self, world, self.GetAngleTo(safePlace.X, safePlace.Y)) + Pi / 2;
                }
            }
            if (self.Life < 0.35 * self.MaxLife)
            {
                if (self.GetDistanceTo(Find.NearestEnemyUnit(self, world)) < 600)
                {
                    move.Speed = -3;
                    move.Turn = FreeAngle(self, world, self.GetAngleTo(safePlace.X, safePlace.Y)) + Pi / 2;
                }
            }

            if (self.SpeedX < 0.1 && self.SpeedY < 0.1 && world.TickIndex > 100 && !stop)
            {
                move.StrafeSpeed = rnd.Next(-2,2);
            }
        }




        public static Point SafePlace(Wizard self, World world)
        {
            Point safePlace = new Point();
            Point now = new Point(self.X, self.Y);
            if (l1.IsYMore(now))
            {
                safePlace.X = 0;
                safePlace.Y = 4000;
            }
            else
            {
                if (l2.IsYMore(now))
                {
                    safePlace.X = 4000;
                    safePlace.Y = 4000;
                }
                else
                {
                    safePlace.X = 0;
                    safePlace.Y = 4000;
                }
                if (!l3.IsYMore(now))
                {
                    safePlace.X = 0;
                    safePlace.Y = 0;
                }
            }
            return safePlace;
        }
        public double FreeAngle(Wizard self, World world, double needAngle)
        {
            double startAngle = needAngle - Pi / 16;
            double finAngle = needAngle + Pi / 16;
            int minRightSector;
            int minLeftSector;

            if (IsFreeSector(self, world, startAngle, finAngle))
                return needAngle;

            for(minRightSector = 1; minRightSector < 8; minRightSector++)
            {
                if (IsFreeSector(self, world, startAngle + Pi * minRightSector / 8, finAngle + Pi * minRightSector / 8))
                    break;
            }
            for (minLeftSector = 1; minLeftSector < 8; minLeftSector++)
            {
                if (IsFreeSector(self, world, startAngle + Pi * minLeftSector / 8, finAngle + Pi * minLeftSector / 8))
                    break;
            }

            if (minRightSector < minLeftSector)
                return needAngle + Pi * minRightSector / 8;
            else
                return needAngle + Pi * minLeftSector / 8;
        }
        public bool IsFreeSector(Wizard self, World world, double startAngle, double finAngle)
        {
            double maxDist = 200;
            double angle;
            double a;
            double fi;
            double dist;
            double r;

            foreach (Tree tree in world.Trees)
            {
                dist = self.GetDistanceTo(tree);
                angle = self.GetAngleTo(tree);
                r = tree.Radius + 35;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            foreach (Wizard wizard in world.Wizards)
            {
                dist = self.GetDistanceTo(wizard);
                angle = self.GetAngleTo(wizard);
                r = wizard.Radius + 15;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (wizard.SpeedX > self.SpeedX / 2 && wizard.SpeedY > self.SpeedY / 2 && dist < 150)
                    continue;
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            foreach (Minion minion in world.Minions)
            {
                dist = self.GetDistanceTo(minion);
                angle = self.GetAngleTo(minion);
                r = minion.Radius + 15;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (minion.SpeedX > self.SpeedX / 2 && minion.SpeedY > self.SpeedY / 2 && dist < 150)
                    continue;
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            foreach (Building building in world.Buildings)
            {
                dist = self.GetDistanceTo(building);
                angle = self.GetAngleTo(building);
                r = building.Radius + 35;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            return true;
        }
        private static void KillUnit(Wizard self, Move move, World world, CircularUnit unit)
        {
            needAngle = self.GetAngleTo(unit);
            move.Speed = 4;
            stop = false;
            if (self.GetDistanceTo(unit) < 500)
            {
                move.Speed = 0;
                move.StrafeSpeed = 0;
                stop = true;
                move.Turn = self.GetAngleTo(unit);
            }
            if (stop)
            {
                if (self.GetDistanceTo(unit) < 250)
                {
                    move.Speed = -2;
                    move.Turn = self.GetAngleTo(unit);
                }
            }
        }
        public static void Attack(Wizard self, Move move, World world)
        {
            CircularUnit unitForAttack = Find.UnitForAttack(self, world, true) == null ? Find.UnitForAttack(self, world, false) : Find.UnitForAttack(self, world, true);
            CircularUnit nearestEnemyUnit = Find.NearestEnemyUnit(self, world);
            if (unitForAttack != null)
                KillUnit(self, move, world, unitForAttack);
            else if (nearestEnemyUnit != null)
                KillUnit(self, move, world, nearestEnemyUnit);
        }
    }
}