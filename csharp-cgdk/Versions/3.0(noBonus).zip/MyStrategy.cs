using Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk.Model;
using System;

namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk
{
    public sealed class MyStrategy : IStrategy
    {
        public static double needAngle;
        public static double Pi = Math.PI;
        public static bool stop;
        public static Random rnd = new Random();
        public static Line l1 = new Line(250);
        public static Line l2 = new Line(1200, 4000, 3600, 800);
        public static Line l3 = new Line(0, 2800, 3200, 400);
        public static bool bonus = false;
        public static bool takeBonus = false;

        public void Move(Wizard self, World world, Game game, Move move)
        {
            int bonusTime = 300; //(int)(self.GetDistanceTo(2800, 2800) / 4.5);
            Point safePlace = SafePlace(self, world);
            needAngle = world.TickIndex > 200 ? self.GetAngleTo(world.Width, 0) : self.GetAngleTo(world.Width, world.Width);
            move.Speed = world.TickIndex < 150 ? 0 : 4;
            move.Action = world.TickIndex % 2 == 0 ? ActionType.MagicMissile : ActionType.Staff;
            //if(!bonus)
            Kill(self, move, world);

            //if ((bonus || world.TickIndex % 2500 > 2500 - bonusTime)||(self.GetDistanceTo(2800,2800)<400&& !takeBonus))
            //{
            //    Console.WriteLine("-b");
            //    bonus = true;
            //    if (!l1.IsYMore(self.X, self.Y))
            //        needAngle = self.GetAngleTo(2800, 2800);
            //    else
            //        Kill(self, move, world);
            //    //if (world.TickIndex % 2500 < 2600)
            //    //{
            //    //    move.Speed = -3;
            //    //    needAngle = self.GetAngleTo(4000, 0) - Pi/2;
            //    //}
            //    // MakeWay(self, move, world, self.GetAngleTo(2800, 2800));
            //    if (self.GetDistanceTo(2800, 2800) < self.Radius + 10 || self.Life < 0.15 * self.MaxLife)
            //        takeBonus = true;
            //        bonus = false;
            //}
            if (!stop)
                move.Turn = FreeAngle(self, world, needAngle);
            double warningAngle = FindUnitToKill(self, world) == null ? self.GetAngleTo(4000, 0) : self.GetAngleTo(FindUnitToKill(self, world));
            double warningDist = FindUnitToKill(self, world) == null ? 1000 : self.GetDistanceTo(FindUnitToKill(self, world));
            if (self.Life < 0.6 * self.MaxLife)
            {
                if (warningDist < 400)
                {
                    move.Speed = -1.5;
                    move.Turn = warningAngle; // FreeAngle(self, world, self.GetAngleTo(safePlace.X, safePlace.Y)) + Pi / 2;
                }
            }
            if (self.Life < 0.45 * self.MaxLife)
            {
                if (warningDist < 500)
                {
                    move.Speed = -2.3;
                    move.Turn = warningAngle; //FreeAngle(self, world, self.GetAngleTo(safePlace.X, safePlace.Y)) + Pi / 2;
                }
            }
            if (self.Life < 0.35 * self.MaxLife)
            {
                //if (warningDist < 600)
                //{
                    move.Speed = -3;
                    move.Turn = warningAngle; // FreeAngle(self, world, self.GetAngleTo(safePlace.X, safePlace.Y)) + Pi / 2;
                //}
            }

            if (self.SpeedX < 0.1 && self.SpeedY < 0.1 && world.TickIndex > 100 && !stop)
            {
                move.StrafeSpeed = rnd.Next(-2,2);
            }
        }




        public static Point SafePlace(Wizard self, World world)
        {
            Point safePlace = new Point();
            Point now = new Point(self.X, self.Y);
            if (l1.IsYMore(now))
            {
                safePlace.X = 0;
                safePlace.Y = 4000;
            }
            else
            {
                if (l2.IsYMore(now))
                {
                    safePlace.X = 4000;
                    safePlace.Y = 4000;
                }
                else
                {
                    safePlace.X = 0;
                    safePlace.Y = 4000;
                }
                if (!l3.IsYMore(now))
                {
                    safePlace.X = 0;
                    safePlace.Y = 0;
                }
            }
            return safePlace;
        }
        public double FreeAngle(Wizard self, World world, double needAngle)
        {
            double startAngle = needAngle - Pi / 16;
            double finAngle = needAngle + Pi / 16;
            int minRightSector;
            int minLeftSector;

            if (IsFreeSector(self, world, startAngle, finAngle))
                return needAngle;

            for(minRightSector = 1; minRightSector < 8; minRightSector++)
            {
                if (IsFreeSector(self, world, startAngle + Pi * minRightSector / 8, finAngle + Pi * minRightSector / 8))
                    break;
            }
            for (minLeftSector = 1; minLeftSector < 8; minLeftSector++)
            {
                if (IsFreeSector(self, world, startAngle + Pi * minLeftSector / 8, finAngle + Pi * minLeftSector / 8))
                    break;
            }

            if (minRightSector < minLeftSector)
                return needAngle + Pi * minRightSector / 8;
            else
                return needAngle + Pi * minLeftSector / 8;
        }
        public bool IsFreeSector(Wizard self, World world, double startAngle, double finAngle)
        {
            double maxDist = 200;
            double angle;
            double a;
            double fi;
            double dist;
            double r;

            foreach (Tree tree in world.Trees)
            {
                dist = self.GetDistanceTo(tree) - 50;
                angle = self.GetAngleTo(tree);
                r = tree.Radius + 50;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            foreach (Wizard wizard in world.Wizards)
            {
                dist = self.GetDistanceTo(wizard);
                angle = self.GetAngleTo(wizard);
                r = wizard.Radius + 10;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (wizard.SpeedX > self.SpeedX / 3 && wizard.SpeedY > self.SpeedY / 2 && dist < 150)
                    continue;
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            foreach (Minion minion in world.Minions)
            {
                dist = self.GetDistanceTo(minion);
                angle = self.GetAngleTo(minion);
                r = minion.Radius - 10;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (minion.SpeedX > self.SpeedX / 3 && minion.SpeedY > self.SpeedY / 2 && dist < 150)
                    continue;
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            foreach (Building building in world.Buildings)
            {
                dist = self.GetDistanceTo(building);
                angle = self.GetAngleTo(building);
                r = building.Radius + 35;
                a = Math.Sqrt(dist * dist - r * r);
                fi = Math.Acos(a / dist);
                if (dist < maxDist && angle + fi > startAngle && angle - fi < finAngle)
                    return false;
            }
            return true;
        }
        private static void KillUnit(Wizard self, Move move, World world, CircularUnit unit)
        {
            needAngle = self.GetAngleTo(unit);
            move.Speed = 4;
            stop = false;
            if (self.GetDistanceTo(unit) < 500)
            {
                move.Speed = 0;
                stop = true;
                move.Turn = self.GetAngleTo(unit);
            }
            else
            {
                needAngle = self.GetAngleTo(4000, 0);
                stop = false;
            }
            if (stop)
            {
                if (self.GetDistanceTo(unit) < 250)
                {
                    move.Speed = -2;
                    move.Turn = self.GetAngleTo(unit);
                }
            }
        }
        public static void Kill(Wizard self, Move move, World world)
        {
            CircularUnit unitForKill = FindUnitToKill(self, world);
            if (unitForKill != null)
                KillUnit(self, move, world, unitForKill);
        }
        public static CircularUnit FindUnitToKill(Wizard self, World world)
        {
            bool isInShutDist = false;
            CircularUnit unitToKill = null;
            double minDistance = 10000;
            int minLife = 100000;
            double d;
            int life;
            bool b;

            foreach(Building unit in world.Buildings)
            {
                b = false;
                foreach (Tree t in world.Trees)
                {
                    if (Math.Abs(self.GetAngleTo(t) - self.GetAngleTo(unit)) < Pi / 16)
                    {
                        b = true;
                        break;
                    }
                }
                d = self.GetDistanceTo(unit);
                life = unit.Life;
                if (d < 500)
                {
                    if (b)
                        continue;
                    isInShutDist = true;
                    if (unit.Faction != self.Faction && life < minLife)
                    {
                        minLife = life;
                        unitToKill = unit;
                    }
                }
                else
                {
                    if (isInShutDist)
                        continue;
                    else
                    {
                        if (unit.Faction != self.Faction && d < minDistance)
                        {
                            minDistance = d;
                            unitToKill = unit;
                        }
                    }
                }
            }
            foreach (Wizard unit in world.Wizards)
            {
                b = false;
                foreach (Tree t in world.Trees)
                {
                    if (Math.Abs(self.GetAngleTo(t) - self.GetAngleTo(unit)) < Pi / 16)
                    {
                        b = true;
                        break;
                    }
                }
                d = self.GetDistanceTo(unit);
                life = unit.Life;
                if (d < 500)
                {
                    if (b)
                        continue;
                    isInShutDist = true;
                    if (unit.Faction != self.Faction && life < minLife)
                    {
                        minLife = life;
                        unitToKill = unit;
                    }
                }
                else
                {
                    if (isInShutDist)
                        continue;
                    else
                    {
                        if (unit.Faction != self.Faction && d < minDistance)
                        {
                            minDistance = d;
                            unitToKill = unit;
                        }
                    }
                }
            }
            foreach (Minion unit in world.Minions)
            {
                b = false;
                foreach (Tree t in world.Trees)
                {
                    if (Math.Abs(self.GetAngleTo(t) - self.GetAngleTo(unit)) < Pi / 16)
                    {
                        b = true;
                        break;
                    }
                }
                d = self.GetDistanceTo(unit);
                life = unit.Life;
                if (d < 500)
                {
                    if (b)
                        continue;
                    isInShutDist = true;
                    if (unit.Faction != self.Faction && unit.Faction != Faction.Neutral && life < minLife)
                    {
                        minLife = life;
                        unitToKill = unit;
                    }
                }
                else
                {
                    if (isInShutDist)
                        continue;
                    else
                    {
                        if (unit.Faction != self.Faction && d < minDistance)
                        {
                            minDistance = d;
                            unitToKill = unit;
                        }
                    }
                }
            }
            return unitToKill;
        }
        public static void MakeWay(Wizard self, Move move, World world, double angle)
        {
            move.Turn = angle;
            move.Speed = 3;
            foreach(Tree t in world.Trees)
            {
                if (Math.Abs(self.GetAngleTo(t) - angle) < Pi / 16 && self.GetDistanceTo(t) < 300)
                {
                    move.Speed = 0;
                    move.Turn = self.GetAngleTo(t);
                }
            }
            foreach (Minion m in world.Minions)
            {
                if (m.Faction==Faction.Neutral&&Math.Abs(self.GetAngleTo(m) - angle) < Pi / 16 && self.GetDistanceTo(m) < 300)
                {
                    move.Speed = 0;
                    move.Turn = self.GetAngleTo(m);
                }
            }
        }
    }
}