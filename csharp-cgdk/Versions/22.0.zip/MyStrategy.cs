

//�������� �������� ���� ��������, ���� ����������� ���� ������� ������������� ������.
//��� ������ �������� ��� - �����.


using Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk.Model;
using System;

namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk
{
    public sealed class MyStrategy : IStrategy
    {
        public void Move(Wizard self, World world, Game game, Move move)
        {
            move.Turn = self.Y > -self.X + 3850 ? self.Y > self.X + 800 ? self.GetAngleTo(world.Width - 1000, 0) : self.GetAngleTo(world.Width, 0) : self.GetAngleTo(2000, 2000);
            move.Speed = 4;
            move.Action = world.TickIndex % 2 == 0 ? ActionType.MagicMissile : ActionType.Staff;
            if (world.TickIndex > 400 && self.X < 600 && self.Y > 3400)
            {
                move.Turn = self.GetAngleTo(4000, 4000);
            }
            Logic.Attack(self, move, world, true);
            Logic.Stop(move, world, 70);
            //Console.WriteLine("{0:3}, {1:3}", self.SpeedX, self.SpeedY);
            

            Building nearestEnemyBuilding = Find.NearestEnemyBuilding(self, world);
            Minion nearestEnemyMinion = Find.NearestEnemyMinion(self, world);
            Wizard nearestEnemyWizard = Find.NearestEnemyWizard(self, world);
            double d1 = nearestEnemyBuilding == null ? 1500 : self.GetDistanceTo(nearestEnemyBuilding);
            double d2 = nearestEnemyMinion == null ? 1500 : self.GetDistanceTo(nearestEnemyMinion);
            double d3 = nearestEnemyWizard == null ? 1500 : self.GetDistanceTo(nearestEnemyWizard);
            double delta = 200;

            if (d1 <= delta || d2 <= delta || d3 <= delta)
            {
                //move.Turn = self.GetAngleTo(world.Width, 0);
                Logic.stop = false;
                move.Speed = -3;
                if (d1 > 600 && d2 > 600 && d3 > 600)
                    Logic.Stop(move, world, world.TickIndex + 2);
            }

            if (d1 <= delta || d2 <= delta || d3 <= delta || need_to_run(self, move, world))
            {
                //move.Turn = self.GetAngleTo(world.Width, 0);
                Logic.stop = false;
                move.Speed = -2;
                if (d1 > 550 && d2 > 550 && d3 > 550)
                    Logic.Stop(move, world, world.TickIndex + 2);
            }

            Logic.ActionWithBonus(world, self, move);
            //Logic.KeepDistance(self, move, world, 70);

            if (self.Life <= self.MaxLife * 0.3)
            {
                move.Turn = self.GetAngleTo(world.Width, 200);
                move.Speed = -3;
                Logic.stop = false;
                if (d1 > 620 && d2 > 620 && d3 > 620)
                    Logic.Stop(move, world, world.TickIndex + 5);
            }

            //Logic.CorrectCourse(self, move, world);
            Logic.Bypass(self, move, world);
            Logic.Barrier(self, move, world, game);
            
        }
        static public bool need_to_run(Wizard self, Move move, World world)
        {
            double enemy_life = 0;
            int enemy_count = 0;
            foreach (Minion minion in world.Minions)
            {
                if (self.Faction != minion.Faction && minion.Faction != Faction.Neutral && self.GetDistanceTo(minion) <= self.CastRange + minion.Radius + 10)
                {
                    enemy_life += minion.Life;
                    enemy_count++;
                }
            }
            foreach (Wizard wizard in world.Wizards)
            {
                if (self.Faction != wizard.Faction && wizard.Faction != Faction.Neutral && self.GetDistanceTo(wizard) <= self.CastRange + wizard.Radius + 10)
                {
                    enemy_life += wizard.Life;
                    enemy_count++;
                }
            }
            foreach (Building build in world.Buildings)
            {
                if (self.Faction != build.Faction && build.Faction != Faction.Neutral && self.GetDistanceTo(build) <= self.CastRange + build.Radius + 10)
                {
                    enemy_life += build.Life;
                    enemy_count++;
                }
            }
            double our_life = self.Life;
            int our_count = 0;
            foreach (Minion minion in world.Minions)
            {
                if (self.Faction == minion.Faction && self.GetDistanceTo(minion) <= self.CastRange + minion.Radius + 10)
                {
                    our_life += minion.Life;
                    our_count++;
                }
            }
            foreach (Wizard wizard in world.Wizards)
            {
                if (self.Faction == wizard.Faction && self.GetDistanceTo(wizard) <= self.CastRange + wizard.Radius + 10)
                {
                    our_life += wizard.Life;
                    our_count++;
                }
            }
            //Console.WriteLine((double)enemy_life / our_life + "\t" + our_life + "\t" + enemy_life);
            if (our_life * 1.2 < enemy_life || our_count + 2 < enemy_count)
                return true;
            return false;
        }
    }
}